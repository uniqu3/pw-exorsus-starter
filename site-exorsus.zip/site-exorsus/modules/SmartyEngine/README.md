# SmartyEngine
Smarty Engine for ProcessWire
