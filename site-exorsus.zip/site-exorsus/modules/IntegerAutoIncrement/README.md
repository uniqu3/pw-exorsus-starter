# IntegerAutoIncrement
ProcessWire - Adds additional option to Fieldtype Integer to make it auto increment.

# Changelog

Ironman (0.0.1)
* Initial release
