Pia - Pageimage Assistant
======================

### Module for ProcessWire 2.5.0+ and 3.0+

#### Version 1.0.0

Documentation is in the supportforum at:
https://processwire.com/talk/topic/8367-pia-pageimage-assistant/