MarkupSEO
=========

The all-in-one SEO solution for ProcessWire.
More over here: https://processwire.com/talk/topic/8007-markupseo-the-all-in-one-seo-solution-for-processwire/


### Todo

- Character count
