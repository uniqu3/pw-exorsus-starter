<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Exorsus - Schnellstart Profil", 
	'summary' => "", 
	'screenshot' => "exorsus-screenshot.jpg"
	);
