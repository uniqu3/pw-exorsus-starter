<?php namespace ProcessWire;

class Person extends Page
{

}
